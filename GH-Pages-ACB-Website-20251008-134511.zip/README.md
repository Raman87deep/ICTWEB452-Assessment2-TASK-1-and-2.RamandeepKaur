# ACB Systems – GitHub Pages Package

This zip is pre-structured for GitHub Pages using the **`/docs`** folder on the default branch.

## What's inside
```
/docs
  ├── index.html
  ├── about.html
  ├── services.html
  ├── contact.html
  ├── 404.html
  ├── styles.css
  ├── script.js
  ├── favicon.ico
  ├── Readme.html
  ├── ICTWEB452 - LLA2 .RamandeepKaur Task1.docx
  └── .nojekyll
```
All links are **relative** (e.g., `./styles.css`, `about.html`) so pages work locally and on GitHub Pages.

## How to publish (Option A: `/docs` folder on `main`)
1. Create a new GitHub repo (or open your existing one).
2. Upload the **contents of this zip** at the repo root so you have a `/docs` folder in the repo.
3. Go to **Settings → Pages**:
   - **Source**: `Deploy from a branch`
   - **Branch**: select `main` / `master` (your default) and **folder**: `/docs`
   - Save.
4. Wait ~1–2 minutes. Your site will appear at the URL shown on the Pages screen, usually:
   `https://<your-username>.github.io/<your-repo>/`

## How to publish (Option B: serve from repo root)
If you prefer to host from the repository root:
1. Move everything from `/docs` into the repo root.
2. In **Settings → Pages**, set **Branch** to `main` and **Folder** to `/root` (or `/`).
3. Save and wait for deployment.

## Tips
- If you update CSS/JS and don't see changes, try a hard refresh (`Ctrl + F5`) or append a query string (cache bust):
  `styles.css?v=20251008-134511`
- Keep file names the same (case-sensitive).

---

*Package created 08 Oct 2025, 13:45:12*
